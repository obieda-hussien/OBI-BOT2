import yts from "yt-search";
import { ytv, yta } from "./_ytdl.js";
const limit = 100;

const handler = async (m, { conn, text, command }) => {
    if (!text) return m.reply("📌 *اكتب اسم او رابط فيديو علي اليوتيوب .*");
    m.react("⏳")
    let res = await yts(text);
    if (!res || !res.all || res.all.length === 0) {
        return m.reply("No se encontraron resultados para tu búsqueda.");
    }
    let video = res.all[0];
    let total = Number(video?.duration?.seconds) || 0;
    const cap = `
    \`\`\`⊜─⌈ 📻 ◜تشغيل يوتيوب◞ 📻 ⌋─⊜\`\`\`
    ≡ 🌿 *العنوان* : » ${video.title}
    ≡ 🌾 *المؤلف* : » ${video?.author?.name || 'غير متوفر'}
    ≡ 🌱 *المدة* : » ${video?.duration?.timestamp || 'غير متوفر'}
    ≡ 🌴 *المشاهدات* : » ${video.views}
    ≡ ☘️ *الرابط* : » ${video.url}
    тнe вeѕт wнaтѕapp вy DEMON
    `;
    await conn.sendFile(m.chat, await (await fetch(video.thumbnail)).buffer(), "image.jpg", cap, m);
    if (command === "شغل") {
        try {
            const api = await yta(video.url)
            await conn.sendFile(m.chat, api.result.download, api.result.title, "", m);
            await m.react("✔️");
        } catch (error) {
            return error.message
        }
    } else if (command === "شغل2" || command === "شغل فيد") {
        try {
            const api = await ytv(video.url)
            const res = await fetch(api.url);
            const cont = res.headers.get('Content-Length');
            const bytes = parseInt(cont, 10);
            const sizemb = bytes / (1024 * 1024);
            const doc = sizemb >= limit;
            await conn.sendFile(m.chat, api.url, api.title, "", m, null, { asDocument: doc, mimetype: "video/mp4" });
            await m.react("✔️");
        } catch (error) {
            return error.message
        }
    }
}
handler.help = ["شغل", "شغل2"];
handler.tags = ["تنزيل"];
handler.command = ["شغل", "شغل2", "شغل فيد"];

export default handler;