const handler = async function (m, { conn, args }) {
  let postLink = args; // هنا بنجيب أول لينك من الرسالة
  let groupId = '120363418840933998@g.us';
  let [ , channelId, msgId ] = (postLink || '').match(/channel\/([^/]+)\/(\d+)/) || [];
  if (!channelId || !msgId) return m.reply('لينك غير صحيح!');
  await conn.forwardMessage(groupId, { remoteJid: `${channelId}@channel`, id: msgId });
};

handler.command = ['ابعت'];
export default handler;