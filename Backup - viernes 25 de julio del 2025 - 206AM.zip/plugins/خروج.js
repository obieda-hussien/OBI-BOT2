let handler = async (m, { conn, text }) => {
  // حدّد الـ chat أو الجروب اللي هيتنفذ فيه الأمر (لو في نص، ينفذ على الـ jid اللي في النص)
  let id = text ? text : m.chat;

  // رد رسالة تأكيد الخروج
  await conn.reply(id, '┊❄️┊:•⪼ اخذت امر من مطوري بالخروج', m);

  // اخرج من الجروب (لو id جروب)
  await conn.groupLeave(id);
};

handler.command = /^(اخرج|اطلع|غادر|خروج)$/i;
handler.group = true;      // الأمر يعمل فقط في الجروبات
handler.rowner = false;     // الأمر يقتصر على مالك البوت فقط

export default handler;