let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*「✧|─────✦❯◇❮✦─────|✧」*\n*〖❗ تحذير: ادخل مشكلتك أو بلاغك 〗*\n\n*˼‏❖˹┇⇠『مثال:』* \n*${usedPrefix + command} لقد تم حظري من البوت بدون أي سبب*\n*「✧|────✦❯◇❮✦────|✧」*`;

  if (text.length < 10) throw `*〄↞┇❗ تحذير: البلاغ لا يقل عن عشرة أحرف ❗┇*`;
  if (text.length > 1000) throw `*〄↞┇❗ تحذير: البلاغ لا يزيد عن ألف حرف ❗┇*`;

  let teks = `*「✧|────✦❯◇❮✦────|✧」*\n*[إبلاغ مهم]*\n*┬*\n*├❧ الرقم:* wa.me/${m.sender.split`@`[0]}\n*┴*\n*┬*\n*├❧ البلاغ:* ${text}\n*┴*`;

  // أرسل البلاغ إلى رقم المطور (غيّر الرقم حسب المطلوب)
  await conn.sendMessage(
    '201507707325@s.whatsapp.net',
    { text: m.quoted ? teks + '\n\n' + m.quoted.text : teks, contextInfo: { mentionedJid: [m.sender] } }
  );

  // تأكيد للمستخدم أن البلاغ تم إرساله
  await m.reply(`*✧━━ • ━ 「 ✤ 」 ━ • ━━✧*\n*〖تم إبلاغ المطور وإن شاء الله يكون في خدمتك في أسرع وقت〗*\n*✧━━ • ━ 「 ✤ 」 ━ • ━━✧*`);
};

handler.help = ['reporte', 'request'].map(v => v + ' <نص البلاغ>');
handler.tags = ['info'];
handler.command = /^(report|بلاغ|بلغ|ابلاغ|bug|report-owner|reportes)$/i;

export default handler;