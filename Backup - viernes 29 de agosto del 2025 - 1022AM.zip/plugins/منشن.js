const handler = async function (m, { conn, text, participants }) {
  try {
    // نحصل على جميع أيدي المشاركين بالجروب
    let users = participants.map(u => u.id);
    // نرسل الرد مع ذكر الكل
    await conn.sendMessage(m.chat, { text, mentions: users });
  } catch (err) {
    console.error(err);
  }
};
handler.command = ['مشن'];
handler.owner = false; // للجميع
handler.group = true; // فقط في الجروبات
export default handler;