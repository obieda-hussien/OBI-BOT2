// plugins/anti-viewonce.js
import { downloadContentFromMessage } from  @whiskeysockets/baileys 

// ديفولت هندلر (مش هيعمل حاجة)، المهم إننا هنعلّق عليه before
const handler = async (m, extra) => {}

/**
 * هيشتغل تلقائي على أي رسالة viewOnce
 * ويفتحها ويرجع يبعتها كصورة/فيديو عادي مع الكابتشن وذكر صاحبها
 */
handler.before = async function (m, { conn }) {
  try {
    if (!m?.message) return

    // دعم النوعين: viewOnceMessageV2 & viewOnceMessageV2Extension
    const wrapper =
      m.message.viewOnceMessageV2?.message ||
      m.message.viewOnceMessageV2Extension?.message

    if (!wrapper) return // مش رسالة viewOnce

    const type = wrapper.imageMessage
      ?  imageMessage 
      : wrapper.videoMessage
      ?  videoMessage 
      : null

    if (!type) return

    const media = wrapper[type]

    // حمّل الستريم وحوّله لـ Buffer
    const kind = type ===  imageMessage  ?  image  :  video 
    const stream = await downloadContentFromMessage(media, kind)
    const chunks = []
    for await (const chunk of stream) chunks.push(chunk)
    const buffer = Buffer.concat(chunks)

    // ابعت الميديا كرسالة عادية مع الكابتشن + من صاحب الرسالة
    await this.sendMessage(
      m.chat,
      {
        [kind]: buffer,
        caption:
          `👀 *Anti-ViewOnce*\n` +
          `👤 @${m.sender.split( @ )[0]}` +
          (media.caption ? `\n\n${media.caption}` :   )
      },
      { quoted: m, mentions: [m.sender] }
    )

    // نرجّع false عشان ما نوقّفش باقي البلجنات
    return false
  } catch (e) {
    console.error( Anti-ViewOnce error: , e)
  }
}

export default handler